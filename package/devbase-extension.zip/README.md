# Devbase - Chrome Extension

This extention replaces the new tab with a custom page. It shows important links, organized in pre-defined groups.

## How it looks

![Image of Devbase](showcase.png)
